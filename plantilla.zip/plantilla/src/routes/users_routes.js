const express = require('express')
const users_controllers = require('../controllers/users_controller.js')
const router = express.Router()

// Rutas para agregar usuario
router.get('/add', users_controllers.addUserForm);
router.post('/addUser', users_controllers.addUser);

// Rutas para editar usuario
router.get('/edit/:id', users_controllers.editUserForm);
router.post('/update/:id', users_controllers.updateUser);

// Ruta para eliminar usuario
router.post('/delete/:id', users_controllers.deleteUser);

module.exports = router;