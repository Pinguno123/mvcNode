const express = require('express')
const auth_controller = require('../controllers/auth_controller.js')
const router = express.Router()

router.post('/login', auth_controller.login);
router.post('/logout', auth_controller.logout);
router.get('/dashboard', auth_controller.dashboard);

module.exports = router;