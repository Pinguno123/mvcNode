const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const auth_router = require('./routes/auth_routes.js');
const users_router = require('./routes/users_routes.js')
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();

const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(session({
    secret: 'tu_secreto_seguro',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));

// Usar el router de autenticación
app.use('/auth', auth_router);

app.use('/users', users_router);

// Ruta para mostrar el formulario de login
app.get('/login', (req, res) => {
    res.render('login', { errorMessage: '' }); // Renderiza la vista 'login.ejs'
});

app.get('/', (req, res) => {
    res.redirect('/login'); // Redirige al formulario de login por defecto
});

app.listen(port, () => {
    console.log(`Servidor escuchando en el puerto https://localhost:${port}`);
});