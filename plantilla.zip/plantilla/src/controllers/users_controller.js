// users_controller.js
const User = require('../models/user_model.js');

exports.dashboard = async (req, res) => {
    if (req.session.userId) {
        try {
            const users = await User.getAllUsers();
            res.render('dashboard', { username: req.session.username, users: users });
        } catch (err) {
            console.error('Error al obtener usuarios:', err);
            return res.status(500).send('Error al obtener usuarios.');
        }
    } else {
        res.redirect('/login');
    }
};

exports.editUserForm = async (req, res) => {
    if (req.session.userId) {
        const userId = req.params.id;
        try {
            const user = await User.getUserById(userId);
            if (!user) {
                return res.status(404).send('Usuario no encontrado.');
            }
            res.render('users/edit', { user: user });
        } catch (err) {
            console.error('Error al obtener usuario:', err);
            return res.status(500).send('Error al obtener usuario.');
        }
    } else {
        res.redirect('/login');
    }
};

exports.updateUser = async (req, res) => {
    if (req.session.userId) {
        const userId = req.params.id;
        const updatedUser = req.body;
        try {
            await User.updateUser(userId, updatedUser);
            res.redirect('/auth/dashboard');
        } catch (err) {
            console.error('Error al actualizar usuario:', err);
            return res.status(500).send('Error al actualizar usuario.');
        }
    } else {
        res.redirect('/login');
    }
};

exports.addUserForm = (req, res) => {
    if (req.session.userId) {
        res.render('users/add');
    } else {
        res.redirect('/login');
    }
};

exports.addUser = async (req, res) => {
    if (req.session.userId) {
        const newUser = req.body;
        try {
            await User.addUser(newUser);
            res.redirect('/auth/dashboard');
        } catch (err) {
            console.error('Error al agregar usuario:', err);
            return res.status(500).send('Error al agregar usuario.');
        }
    } else {
        res.redirect('/login');
    }
};

exports.deleteUser = async (req, res) => {
    if (req.session.userId) {
        const userId = req.params.id;
        try {
            await User.deleteUser(userId);
            res.redirect('/auth/dashboard');
        } catch (err) {
            console.error('Error al eliminar usuario:', err);
            return res.status(500).send('Error al eliminar usuario.');
        }
    } else {
        res.redirect('/login');
    }
};
