// Archivo controlador encargado del backend del login
const user_model = require('../models/user_model.js'); // Import the user model

async function login(req, res) {
    const { username, password } = req.body;

    try {
        const user = await user_model.getUserByUsername(username, password);

        if (user && user.password === password) {
            req.session.userId = user.id;
            req.session.username = user.username;
            return res.redirect('/auth/dashboard'); // Redirige al dashboard
        } else {
            return res.render('login', { errorMessage: 'Credenciales inválidas' }); // Renderiza la vista de login con mensaje de error
        }
    } catch (error) {
        console.error('Error al iniciar sesión:', error);
        return res.render('login', { errorMessage: 'Error al iniciar sesión' }); // Renderiza la vista de login con mensaje de error
    }
}

function logout(req, res) {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error al cerrar sesión:', err);
            return res.status(500).send('Error al cerrar sesión.'); // Mantener el status 500 en caso de error interno
        }
        res.redirect('/login'); // Redirige a la página de login
    });
}

async function dashboard(req, res) {
    if (req.session.userId) {
        try {
            const users = await user_model.getAllUsers(); // Fetch all users
            return res.render('dashboard', { username: req.session.username, users: users }); // Pass users to the view
        } catch (error) {
            console.error('Error fetching users:', error);
            return res.render('dashboard', { username: req.session.username, users: [], errorMessage: 'Error al obtener usuarios' }); // Handle error and pass an empty array
        }
    } else {
        return res.redirect('/login');
    }
}

module.exports = {
    login,
    logout,
    dashboard
};
