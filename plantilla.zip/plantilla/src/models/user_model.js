// Archivo que maneja la informacion sobre el usuario en la base de datos (funcionalidades del login Y CRUD)
const pool = require('./conexion.js');

async function getUserByUsername(username, password) {
    let connection;
    try {
        connection = await pool.getConnection();
        const [rows] = await connection.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password]);
        return rows[0];
    } catch (error) {
        console.error('Error al obtener usuario:', error);
        throw error;
    } finally {
        if (connection) connection.release(); // Release the connection back to the pool
    }
}

async function getAllUsers() {
    let connection;
    try {
        connection = await pool.getConnection();
        const [rows] = await connection.query('SELECT * FROM users');
        return rows;
    } catch (error) {
        console.error('Error al obtener todos los usuarios:', error);
        throw error;
    } finally {
        if (connection) connection.release();
    }
}

async function getUserById(id) {
    let connection;
    try {
        connection = await pool.getConnection();
        const [rows] = await connection.query('SELECT * FROM users WHERE id = ?', [id]);
        return rows[0];
    } catch (error) {
        console.error('Error al obtener usuario por ID:', error);
        throw error;
    } finally {
        if (connection) connection.release();
    }
}

async function addUser(newUser) {
    let connection;
    try {
        connection = await pool.getConnection();
        const [result] = await connection.query('INSERT INTO users SET ?', newUser);
        return result.insertId;
    } catch (error) {
        console.error('Error al agregar usuario:', error);
        throw error;
    } finally {
        if (connection) connection.release();
    }
}

async function updateUser(id, updatedUser) {
    let connection;
    try {
        connection = await pool.getConnection();
        const [result] = await connection.query('UPDATE users SET ? WHERE id = ?', [updatedUser, id]);
        return result.affectedRows;
    } catch (error) {
        console.error('Error al actualizar usuario:', error);
        throw error;
    } finally {
        if (connection) connection.release();
    }
}

async function deleteUser(id) {
    let connection;
    try {
        connection = await pool.getConnection();
        const [result] = await connection.query('DELETE FROM users WHERE id = ?', [id]);
        return result.affectedRows;
    } catch (error) {
        console.error('Error al eliminar usuario:', error);
        throw error;
    } finally {
        if (connection) connection.release();
    }
}

module.exports = {
    getUserByUsername,
    getAllUsers,
    getUserById,
    addUser,
    updateUser,
    deleteUser
};